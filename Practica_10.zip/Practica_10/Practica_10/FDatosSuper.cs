﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Practica_10
{
    public partial class FDatosSuper : Form
    {
        public Superheroe Superheroe { get; private set; }

        public FDatosSuper()
        {
            InitializeComponent();
            Superheroe = null;
        }

        public FDatosSuper(Superheroe super) : this()
        {
            Superheroe = super;
            CargarDatos(super);
        }

        private void btaceptar_Click(object sender, EventArgs e)
        {
            if (pbfoto.Image == null)
            {
                MessageBox.Show("Debes seleccionar una imagen.");
                return;
            }

            // CREAR NUEVO SUPERHÉROE
            if (Superheroe == null || Superheroe.ID == 0)
            {
                Superheroe = new Superheroe(
                    txtnombre.Text,
                    txtpoder.Text,
                    (Bitmap)pbfoto.Image,
                    (int)numnivel.Value
                );

                Superheroe.GuardarBD(); // INSERT
            }
            else
            {
                // EDITAR EXISTENTE
                Superheroe.Nombre = txtnombre.Text;
                Superheroe.Poder = txtpoder.Text;
                Superheroe.Nivel = (int)numnivel.Value;
                Superheroe.Imagen = (Bitmap)pbfoto.Image;

                Superheroe.ActualizarBD(); // UPDATE
            }

            DialogResult = DialogResult.OK;
            Close();
        }

        private void btagregar_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                pbfoto.Image = new Bitmap(openFileDialog1.FileName);
            }
        }

        public void CargarDatos(Superheroe super)
        {
            if (super == null) return;

            txtnombre.Text = super.Nombre;
            txtpoder.Text = super.Poder;
            numnivel.Value = super.Nivel;

            if (super.Imagen != null)
                pbfoto.Image = new Bitmap(super.Imagen);
        }
    }
}
