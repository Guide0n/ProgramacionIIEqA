﻿namespace Practica_10
{
    partial class FDatosSuper
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbnombre = new System.Windows.Forms.Label();
            this.lbpoder = new System.Windows.Forms.Label();
            this.lbnivel = new System.Windows.Forms.Label();
            this.lbfoto = new System.Windows.Forms.Label();
            this.btagregar = new System.Windows.Forms.Button();
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.txtpoder = new System.Windows.Forms.TextBox();
            this.numnivel = new System.Windows.Forms.NumericUpDown();
            this.pbfoto = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btaceptar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numnivel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbfoto)).BeginInit();
            this.SuspendLayout();
            // 
            // lbnombre
            // 
            this.lbnombre.AutoSize = true;
            this.lbnombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbnombre.Location = new System.Drawing.Point(31, 31);
            this.lbnombre.Name = "lbnombre";
            this.lbnombre.Size = new System.Drawing.Size(69, 20);
            this.lbnombre.TabIndex = 0;
            this.lbnombre.Text = "Nombre:";
            // 
            // lbpoder
            // 
            this.lbpoder.AutoSize = true;
            this.lbpoder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbpoder.Location = new System.Drawing.Point(31, 69);
            this.lbpoder.Name = "lbpoder";
            this.lbpoder.Size = new System.Drawing.Size(55, 20);
            this.lbpoder.TabIndex = 1;
            this.lbpoder.Text = "Poder:";
            // 
            // lbnivel
            // 
            this.lbnivel.AutoSize = true;
            this.lbnivel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbnivel.Location = new System.Drawing.Point(31, 106);
            this.lbnivel.Name = "lbnivel";
            this.lbnivel.Size = new System.Drawing.Size(113, 20);
            this.lbnivel.TabIndex = 2;
            this.lbnivel.Text = "Nivel de poder:";
            // 
            // lbfoto
            // 
            this.lbfoto.AutoSize = true;
            this.lbfoto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbfoto.Location = new System.Drawing.Point(31, 144);
            this.lbfoto.Name = "lbfoto";
            this.lbfoto.Size = new System.Drawing.Size(46, 20);
            this.lbfoto.TabIndex = 3;
            this.lbfoto.Text = "Foto:";
            // 
            // btagregar
            // 
            this.btagregar.Location = new System.Drawing.Point(83, 144);
            this.btagregar.Name = "btagregar";
            this.btagregar.Size = new System.Drawing.Size(75, 25);
            this.btagregar.TabIndex = 4;
            this.btagregar.Text = "Agregar";
            this.btagregar.UseVisualStyleBackColor = true;
            this.btagregar.Click += new System.EventHandler(this.btagregar_Click);
            // 
            // txtnombre
            // 
            this.txtnombre.Location = new System.Drawing.Point(116, 32);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.Size = new System.Drawing.Size(114, 20);
            this.txtnombre.TabIndex = 5;
            // 
            // txtpoder
            // 
            this.txtpoder.Location = new System.Drawing.Point(92, 71);
            this.txtpoder.Name = "txtpoder";
            this.txtpoder.Size = new System.Drawing.Size(114, 20);
            this.txtpoder.TabIndex = 6;
            // 
            // numnivel
            // 
            this.numnivel.Location = new System.Drawing.Point(150, 106);
            this.numnivel.Name = "numnivel";
            this.numnivel.Size = new System.Drawing.Size(98, 20);
            this.numnivel.TabIndex = 7;
            // 
            // pbfoto
            // 
            this.pbfoto.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pbfoto.Location = new System.Drawing.Point(191, 144);
            this.pbfoto.Name = "pbfoto";
            this.pbfoto.Size = new System.Drawing.Size(240, 134);
            this.pbfoto.TabIndex = 8;
            this.pbfoto.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btaceptar
            // 
            this.btaceptar.Location = new System.Drawing.Point(387, 284);
            this.btaceptar.Name = "btaceptar";
            this.btaceptar.Size = new System.Drawing.Size(75, 23);
            this.btaceptar.TabIndex = 9;
            this.btaceptar.Text = "Aceptar";
            this.btaceptar.UseVisualStyleBackColor = true;
            this.btaceptar.Click += new System.EventHandler(this.btaceptar_Click);
            // 
            // FDatosSuper
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(474, 317);
            this.Controls.Add(this.btaceptar);
            this.Controls.Add(this.pbfoto);
            this.Controls.Add(this.numnivel);
            this.Controls.Add(this.txtpoder);
            this.Controls.Add(this.txtnombre);
            this.Controls.Add(this.btagregar);
            this.Controls.Add(this.lbfoto);
            this.Controls.Add(this.lbnivel);
            this.Controls.Add(this.lbpoder);
            this.Controls.Add(this.lbnombre);
            this.Name = "FDatosSuper";
            this.Text = "FDatosSuper";
            ((System.ComponentModel.ISupportInitialize)(this.numnivel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbfoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbnombre;
        private System.Windows.Forms.Label lbpoder;
        private System.Windows.Forms.Label lbnivel;
        private System.Windows.Forms.Label lbfoto;
        private System.Windows.Forms.Button btagregar;
        private System.Windows.Forms.TextBox txtnombre;
        private System.Windows.Forms.TextBox txtpoder;
        private System.Windows.Forms.NumericUpDown numnivel;
        private System.Windows.Forms.PictureBox pbfoto;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btaceptar;
    }
}