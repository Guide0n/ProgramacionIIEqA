﻿using System;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;

namespace Practica_10
{
    public class Superheroe
    {
        public int ID { get; set; }
        public string Nombre { get; set; }
        public string Poder { get; set; }
        public Bitmap Imagen { get; set; }
        public int Nivel { get; set; }

        public int? IdUniverso { get; set; }
        public bool AsignadoAUniverso => IdUniverso != null;

        public Superheroe(string nombre, string poder, Bitmap imagen, int nivel)
        {
            Nombre = nombre;
            Poder = poder;
            Imagen = imagen;
            Nivel = nivel;
        }

        public Superheroe(int id, string nombre, string poder, Bitmap imagen, int nivel)
        {
            ID = id;
            Nombre = nombre;
            Poder = poder;
            Imagen = imagen;
            Nivel = nivel;
        }

        public string MostrarDatos()
        {
            return $"{Nombre} - {Poder} (Nivel {Nivel})";
        }

        public void GuardarBD()
        {
            string cadena = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=BDUniversoySuperheroes;";

            using (SqlConnection conexion = new SqlConnection(cadena))
            {
                conexion.Open();

                string query = @"INSERT INTO TbSuperheroes (Nombre, Poder, Imagen, Nivel)
                                 VALUES (@nombre, @poder, @imagen, @nivel);
                                 SELECT SCOPE_IDENTITY();";

                SqlCommand cmd = new SqlCommand(query, conexion);

                cmd.Parameters.AddWithValue("@nombre", Nombre);
                cmd.Parameters.AddWithValue("@poder", Poder);

                MemoryStream ms = new MemoryStream();
                Imagen.Save(ms, Imagen.RawFormat);
                cmd.Parameters.AddWithValue("@imagen", ms.ToArray());

                cmd.Parameters.AddWithValue("@nivel", Nivel);

                ID = Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public void ActualizarBD()
        {
            if (ID <= 0) return;

            string cadena = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=BDUniversoySuperheroes;";

            using (SqlConnection conexion = new SqlConnection(cadena))
            {
                conexion.Open();

                string query = @"UPDATE TbSuperheroes 
                                 SET Nombre=@nombre, Poder=@poder, Imagen=@imagen, Nivel=@nivel
                                 WHERE Id=@id";

                SqlCommand cmd = new SqlCommand(query, conexion);

                cmd.Parameters.AddWithValue("@id", ID);
                cmd.Parameters.AddWithValue("@nombre", Nombre);
                cmd.Parameters.AddWithValue("@poder", Poder);
                cmd.Parameters.AddWithValue("@nivel", Nivel);

                MemoryStream ms = new MemoryStream();
                Imagen.Save(ms, Imagen.RawFormat);
                cmd.Parameters.AddWithValue("@imagen", ms.ToArray());

                cmd.ExecuteNonQuery();
            }
        }

        public override string ToString()
        {
            return MostrarDatos();
        }
    }
}
