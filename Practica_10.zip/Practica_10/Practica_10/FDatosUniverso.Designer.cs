﻿namespace Practica_10
{
    partial class FDatosUniverso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbnomU = new System.Windows.Forms.Label();
            this.lbestado = new System.Windows.Forms.Label();
            this.udnumero = new System.Windows.Forms.NumericUpDown();
            this.lbnumero = new System.Windows.Forms.Label();
            this.txtnomU = new System.Windows.Forms.TextBox();
            this.txtest = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ofdUniverso = new System.Windows.Forms.OpenFileDialog();
            this.btFoto = new System.Windows.Forms.Button();
            this.btaceptar = new System.Windows.Forms.Button();
            this.lbpersonaje = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btAgregar = new System.Windows.Forms.Button();
            this.btFinalizar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.udnumero)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbnomU
            // 
            this.lbnomU.AutoSize = true;
            this.lbnomU.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbnomU.Location = new System.Drawing.Point(33, 24);
            this.lbnomU.Name = "lbnomU";
            this.lbnomU.Size = new System.Drawing.Size(62, 16);
            this.lbnomU.TabIndex = 0;
            this.lbnomU.Text = "Nombre: ";
            // 
            // lbestado
            // 
            this.lbestado.AutoSize = true;
            this.lbestado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbestado.Location = new System.Drawing.Point(33, 56);
            this.lbestado.Name = "lbestado";
            this.lbestado.Size = new System.Drawing.Size(53, 16);
            this.lbestado.TabIndex = 1;
            this.lbestado.Text = "Estado:";
            // 
            // udnumero
            // 
            this.udnumero.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.udnumero.Location = new System.Drawing.Point(146, 89);
            this.udnumero.Name = "udnumero";
            this.udnumero.Size = new System.Drawing.Size(120, 20);
            this.udnumero.TabIndex = 2;
            // 
            // lbnumero
            // 
            this.lbnumero.AutoSize = true;
            this.lbnumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbnumero.Location = new System.Drawing.Point(33, 89);
            this.lbnumero.Name = "lbnumero";
            this.lbnumero.Size = new System.Drawing.Size(107, 16);
            this.lbnumero.TabIndex = 3;
            this.lbnumero.Text = "No. de peliculas:";
            // 
            // txtnomU
            // 
            this.txtnomU.Location = new System.Drawing.Point(101, 20);
            this.txtnomU.Name = "txtnomU";
            this.txtnomU.Size = new System.Drawing.Size(162, 20);
            this.txtnomU.TabIndex = 4;
            // 
            // txtest
            // 
            this.txtest.Location = new System.Drawing.Point(101, 52);
            this.txtest.Name = "txtest";
            this.txtest.Size = new System.Drawing.Size(162, 20);
            this.txtest.TabIndex = 5;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(177, 176);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(261, 173);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // ofdUniverso
            // 
            this.ofdUniverso.FileName = "openFileDialog1";
            // 
            // btFoto
            // 
            this.btFoto.Location = new System.Drawing.Point(59, 176);
            this.btFoto.Name = "btFoto";
            this.btFoto.Size = new System.Drawing.Size(72, 29);
            this.btFoto.TabIndex = 7;
            this.btFoto.Text = "Foto";
            this.btFoto.UseVisualStyleBackColor = true;
            this.btFoto.Click += new System.EventHandler(this.btFoto_Click);
            // 
            // btaceptar
            // 
            this.btaceptar.Location = new System.Drawing.Point(292, 355);
            this.btaceptar.Name = "btaceptar";
            this.btaceptar.Size = new System.Drawing.Size(69, 28);
            this.btaceptar.TabIndex = 8;
            this.btaceptar.Text = "Crear";
            this.btaceptar.UseVisualStyleBackColor = true;
            this.btaceptar.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbpersonaje
            // 
            this.lbpersonaje.AutoSize = true;
            this.lbpersonaje.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbpersonaje.Location = new System.Drawing.Point(33, 120);
            this.lbpersonaje.Name = "lbpersonaje";
            this.lbpersonaje.Size = new System.Drawing.Size(72, 16);
            this.lbpersonaje.TabIndex = 9;
            this.lbpersonaje.Text = "Personaje:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(121, 120);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 10;
            // 
            // btAgregar
            // 
            this.btAgregar.Location = new System.Drawing.Point(248, 120);
            this.btAgregar.Name = "btAgregar";
            this.btAgregar.Size = new System.Drawing.Size(71, 30);
            this.btAgregar.TabIndex = 11;
            this.btAgregar.Text = "Agregar";
            this.btAgregar.UseVisualStyleBackColor = true;
            this.btAgregar.Click += new System.EventHandler(this.btAgregar_Click);
            // 
            // btFinalizar
            // 
            this.btFinalizar.Location = new System.Drawing.Point(367, 355);
            this.btFinalizar.Name = "btFinalizar";
            this.btFinalizar.Size = new System.Drawing.Size(69, 28);
            this.btFinalizar.TabIndex = 12;
            this.btFinalizar.Text = "Aceptar";
            this.btFinalizar.UseVisualStyleBackColor = true;
            // FDatosUniverso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(448, 390);
            this.Controls.Add(this.btFinalizar);
            this.Controls.Add(this.btAgregar);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.lbpersonaje);
            this.Controls.Add(this.btaceptar);
            this.Controls.Add(this.btFoto);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtest);
            this.Controls.Add(this.txtnomU);
            this.Controls.Add(this.lbnumero);
            this.Controls.Add(this.udnumero);
            this.Controls.Add(this.lbestado);
            this.Controls.Add(this.lbnomU);
            this.Name = "FDatosUniverso";
            this.Text = "FDatosUniverso";
            ((System.ComponentModel.ISupportInitialize)(this.udnumero)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbnomU;
        private System.Windows.Forms.Label lbestado;
        private System.Windows.Forms.NumericUpDown udnumero;
        private System.Windows.Forms.Label lbnumero;
        private System.Windows.Forms.TextBox txtnomU;
        private System.Windows.Forms.TextBox txtest;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.OpenFileDialog ofdUniverso;
        private System.Windows.Forms.Button btFoto;
        private System.Windows.Forms.Button btaceptar;
        private System.Windows.Forms.Label lbpersonaje;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btAgregar;
        private System.Windows.Forms.Button btFinalizar;
    }
}