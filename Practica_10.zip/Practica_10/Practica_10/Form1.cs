﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Practica_10
{
    public partial class Form1 : Form
    {
        public List<Superheroe> Superheroes = new List<Superheroe>();

        public Form1()
        {
            InitializeComponent();
            CargardeBD();
            CargarUniversosBD();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void superheroeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FCatalogoSuperheroe v_catalogo_superheroe =
                new FCatalogoSuperheroe(Superheroes);

            v_catalogo_superheroe.ShowDialog();
        }

        private void universoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FCatalogoUniverso v_catalogo_universo = new FCatalogoUniverso();
            v_catalogo_universo.ShowDialog();
        }

        public void CargardeBD()
        {
            string cadena = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=BDUniversoySuperheroes;";
            SqlConnection conexion = new SqlConnection(cadena);
            conexion.Open();

            string query = "SELECT * FROM TbSuperheroes";
            SqlCommand comando = new SqlCommand(query, conexion);
            SqlDataReader lector = comando.ExecuteReader();

            Superheroes = new List<Superheroe>();

            while (lector.Read())
            {
                int id = Convert.ToInt32(lector["Id"]);
                string nombre = lector["Nombre"].ToString();
                string poder = lector["Poder"].ToString();
                int nivel = Convert.ToInt32(lector["Nivel"]);

                // IMAGEN
                byte[] bytes = lector["Imagen"] as byte[];
                Bitmap imagen = null;
                if (bytes != null && bytes.Length > 0)
                {
                    using (MemoryStream ms = new MemoryStream(bytes))
                        imagen = new Bitmap(ms);
                }

                // ID UNIVERSO ✔ MUY IMPORTANTE
                int? idUniverso = lector["IdUniverso"] != DBNull.Value
                    ? Convert.ToInt32(lector["IdUniverso"])
                    : (int?)null;

                Superheroe nuevo = new Superheroe(id, nombre, poder, imagen, nivel);
                nuevo.IdUniverso = idUniverso;

                Superheroes.Add(nuevo);
            }

            comando.Dispose();
            conexion.Close();

            DatosGlobalesS.Superheroes = Superheroes;
        }

        public void CargarUniversosBD()
        {
            string cadena_conexion = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=BDUniversoySuperheroes;";
            SqlConnection conexion = new SqlConnection(cadena_conexion);
            conexion.Open();

            string query = "SELECT * FROM TbUniverso";
            SqlCommand comando = new SqlCommand(query, conexion);
            SqlDataReader lector = comando.ExecuteReader();
            DatosGlobalesU.Universos = new List<Universo>();

            while (lector.Read())
            {
                int id = Convert.ToInt32(lector["Id"]);
                string nombre = lector["Nombre"].ToString();
                string estado = lector["Estado"].ToString();
                int numeros = Convert.ToInt32(lector["Numeros"]);

                byte[] bytes = lector["Imagen"] as byte[];
                Bitmap imagen = null;

                if (bytes != null && bytes.Length > 0)
                    imagen = new Bitmap(new MemoryStream(bytes));

                Universo u = new Universo(id, nombre, estado, numeros, imagen);

                DatosGlobalesU.Universos.Add(u);
            }

            conexion.Close();
        }
    }
}
