﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica_10
{
    public class Universo
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Estado { get; set; }
        public int Numeros { get; set; }
        public Bitmap Imagen { get; set; }
        public List<Superheroe> Superheroes { get; set; }

        public Universo( int id, string nombre, string estado, int numeros, Bitmap imagen)
        {
            Id= id;
            Nombre = nombre;
            Estado = estado;
            Numeros = numeros;
            Imagen = imagen;
            Superheroes = new List<Superheroe>();
        }
        public string getDatos()
        {
            string listaSuperheroes = Superheroes.Count > 0
                ? string.Join(", ", Superheroes.Select(s => s.Nombre))
                : "Ninguno";
            return $"Nombre: {Nombre}, Estado: {Estado}, Numero de Peliculas: {Numeros}, Superheroes: {listaSuperheroes}";
        }
        public void GuardarUBD()
        {
            try
            {
                string cadena_conexion = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=BDUniversoySuperheroes;";
                using (SqlConnection conexion = new SqlConnection(cadena_conexion))
                {
                    conexion.Open();

                    MemoryStream stream = new MemoryStream();
                    Imagen.Save(stream, Imagen.RawFormat);
                    byte[] bytes = stream.ToArray();

                    string query = "INSERT INTO TbUniverso (nombre, estado, numeros, imagen, Superheroe) " +
                                   "VALUES (@nombre, @estado, @numeros, @imagen, @superheroe)";

                    SqlCommand comando = new SqlCommand(query, conexion);

                    comando.Parameters.AddWithValue("@nombre", Nombre);
                    comando.Parameters.AddWithValue("@estado", Estado);
                    comando.Parameters.AddWithValue("@numeros", Numeros);
                    comando.Parameters.AddWithValue("@imagen", bytes);

                    string lista = Superheroes.Count > 0
                        ? Superheroes[0].Nombre              
                        : "Ninguno";

                    comando.Parameters.AddWithValue("@superheroe", lista);

                    comando.ExecuteNonQuery();
                }

                MessageBox.Show("Guardado correctamente");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar: " + ex.Message);
            }
        }

    }
}