﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica_10
{
    public static class DatosGlobalesU
    {
        public static List<Universo> Universos = new List<Universo>();
        public static List<Superheroe> Superheroes = new List<Superheroe>();
    }
}
