﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Practica_10
{
    public partial class FCatalogoSuperheroe : Form
    {
        private List<Superheroe> Superheroes;

        public FCatalogoSuperheroe(List<Superheroe> superheroes)
        {
            InitializeComponent();
            Superheroes = superheroes;
            DesplegarlistaSuperenLB();
        }

        private void btAgregarSuper_Click(object sender, EventArgs e)
        {
            FDatosSuper v_datos_super = new FDatosSuper();

            if (v_datos_super.ShowDialog() == DialogResult.OK)
            {
                Superheroe nuevo = v_datos_super.Superheroe;

                // Agregar a AMBAS listas
                Superheroes.Add(nuevo);
                DatosGlobalesS.Superheroes.Add(nuevo);

                DesplegarlistaSuperenLB();
            }
        }

        private void DesplegarlistaSuperenLB()
        {
            lbSuper.Items.Clear();

            foreach (var super in DatosGlobalesS.Superheroes)
            {
                string universoInfo = super.IdUniverso == null
                    ? "Sin Universo"
                    : $"Universo ID: {super.IdUniverso}";

                lbSuper.Items.Add($"{super.MostrarDatos()} | {universoInfo}");
            }
        }

        private void bt_edit_Click(object sender, EventArgs e)
        {
            int index = lbSuper.SelectedIndex;
            if (index == -1)
            {
                MessageBox.Show("Selecciona un superhéroe para editar.");
                return;
            }

            Superheroe superSeleccionado = Superheroes[index];

            FDatosSuper ventana = new FDatosSuper(superSeleccionado);

            if (ventana.ShowDialog() == DialogResult.OK)
            {
                DesplegarlistaSuperenLB();
            }
        }
        private void FCatalogoSuperheroe_Load_1(object sender, EventArgs e)
        {
            DesplegarlistaSuperenLB();
        }

        private void lbSuper_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

    }
}
