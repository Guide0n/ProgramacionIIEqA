﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Practica_10
{
    public partial class FCatalogoUniverso : Form
    {
        private List<Superheroe> Superheroes;

        public FCatalogoUniverso()
        {
            InitializeComponent();
            Superheroes = DatosGlobalesS.Superheroes;   // Lista REAL desde BD
            this.Load += FCatalogoUniverso_Load;
        }

        private void FCatalogoUniverso_Load(object sender, EventArgs e)
        {
            DesplegarlistaUniversoLB();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // ✔ siempre usamos el constructor sin parámetros
            FDatosUniverso v_datos_universo = new FDatosUniverso();

            if (v_datos_universo.ShowDialog() == DialogResult.OK)
            {
                DatosGlobalesU.Universos.Add(v_datos_universo.Universo);
                DesplegarlistaUniversoLB();
            }
        }

        private void DesplegarlistaUniversoLB()
        {
            lbUniverso.Items.Clear();
            foreach (var universo in DatosGlobalesU.Universos)
                lbUniverso.Items.Add(universo.getDatos());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int index = lbUniverso.SelectedIndex;

            if (index == -1)
            {
                MessageBox.Show("Selecciona un universo para editar.");
                return;
            }

            Universo universoSeleccionado = DatosGlobalesU.Universos[index];

            FDatosUniverso frm = new FDatosUniverso();
            frm.CargarDatos(universoSeleccionado);

            if (frm.ShowDialog() == DialogResult.OK)
            {
                DatosGlobalesU.Universos[index] = frm.Universo;
                DesplegarlistaUniversoLB();
                lbUniverso.SelectedIndex = index;
            }
        }
    }
}
