﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica_10
{
    public static class DatosGlobalesS
    {
        public static List<Superheroe> Superheroes = new List<Superheroe>();
    }
}
