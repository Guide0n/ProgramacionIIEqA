﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Practica_10
{
    public partial class FDatosUniverso : Form
    {
        public Universo Universo { get; private set; }
        public List<Superheroe> Superheroes { get; private set; }

        public FDatosUniverso()
        {
            InitializeComponent();
            Superheroes = DatosGlobalesS.Superheroes;  // ✔ lista REAL
            btAgregar.Enabled = false;
            DesplegarPersonajeenCB();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtnomU.Text))
            {
                MessageBox.Show("Debes escribir un nombre para el universo.");
                return;
            }

            Universo = new Universo(
                0,
                txtnomU.Text,
                txtest.Text,
                (int)udnumero.Value,
                (Bitmap)pictureBox1.Image
            );

            // Guardar en BD
            Universo.GuardarUBD();

            MessageBox.Show(
                $"Universo creado con Id = {Universo.Id}. Ahora puedes agregar superhéroes.",
                "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information
            );

            btAgregar.Enabled = true;
        }

        private void btFoto_Click(object sender, EventArgs e)
        {
            if (ofdUniverso.ShowDialog(this) == DialogResult.OK)
                pictureBox1.Image = new Bitmap(ofdUniverso.FileName);
        }

        private void DesplegarPersonajeenCB()
        {
            comboBox1.Items.Clear();

            var disponibles = Superheroes
                .Where(s => s.IdUniverso == null)    // ✔ solo los libres
                .ToList();

            foreach (var s in disponibles)
                comboBox1.Items.Add(s);

            if (comboBox1.Items.Count > 0)
                comboBox1.SelectedIndex = 0;
        }

        private void btAgregar_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Selecciona un superhéroe para agregar.");
                return;
            }

            if (Universo == null)
            {
                MessageBox.Show("Primero debes crear el universo.");
                return;
            }

            Superheroe seleccionado = (Superheroe)comboBox1.SelectedItem;

            if (seleccionado.IdUniverso != null)
            {
                MessageBox.Show("Este superhéroe ya pertenece a un universo.");
                return;
            }

            Universo.Superheroes.Add(seleccionado);
            seleccionado.IdUniverso = Universo.Id;

            ActualizarUniversoEnBD(seleccionado, Universo.Id);

            MessageBox.Show("Superhéroe agregado correctamente.");

            DesplegarPersonajeenCB();
        }

        private void ActualizarUniversoEnBD(Superheroe s, int idUniverso)
        {
            string cadena = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=BDUniversoySuperheroes;";

            using (SqlConnection conexion = new SqlConnection(cadena))
            {
                conexion.Open();

                string query = "UPDATE TbSuperheroes SET IdUniverso = @idU WHERE Id = @idS";
                SqlCommand cmd = new SqlCommand(query, conexion);

                cmd.Parameters.AddWithValue("@idU", idUniverso);
                cmd.Parameters.AddWithValue("@idS", s.ID);

                cmd.ExecuteNonQuery();
            }
        }

        public void CargarDatos(Universo universo)
        {
            if (universo == null) return;

            Universo = universo;

            txtnomU.Text = universo.Nombre;
            txtest.Text = universo.Estado;
            udnumero.Value = universo.Numeros;

            if (universo.Imagen != null)
                pictureBox1.Image = new Bitmap(universo.Imagen);

            Superheroes = DatosGlobalesS.Superheroes
                .Where(s => s.IdUniverso == null || s.IdUniverso == universo.Id)
                .ToList();

            btAgregar.Enabled = true;
            DesplegarPersonajeenCB();
        }
    }
}
