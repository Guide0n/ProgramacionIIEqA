﻿namespace Practica_10
{
    partial class FCatalogoSuperheroe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btAgregarSuper = new System.Windows.Forms.Button();
            this.lbSuper = new System.Windows.Forms.ListBox();
            this.bt_edit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btAgregarSuper
            // 
            this.btAgregarSuper.Location = new System.Drawing.Point(12, 12);
            this.btAgregarSuper.Name = "btAgregarSuper";
            this.btAgregarSuper.Size = new System.Drawing.Size(74, 30);
            this.btAgregarSuper.TabIndex = 0;
            this.btAgregarSuper.Text = "Agregar";
            this.btAgregarSuper.UseVisualStyleBackColor = true;
            this.btAgregarSuper.Click += new System.EventHandler(this.btAgregarSuper_Click);
            // 
            // lbSuper
            // 
            this.lbSuper.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbSuper.FormattingEnabled = true;
            this.lbSuper.Location = new System.Drawing.Point(95, 90);
            this.lbSuper.Name = "lbSuper";
            this.lbSuper.Size = new System.Drawing.Size(484, 212);
            this.lbSuper.TabIndex = 1;
            this.lbSuper.SelectedIndexChanged += new System.EventHandler(this.lbSuper_SelectedIndexChanged);
            // 
            // bt_edit
            // 
            this.bt_edit.Location = new System.Drawing.Point(95, 12);
            this.bt_edit.Name = "bt_edit";
            this.bt_edit.Size = new System.Drawing.Size(74, 30);
            this.bt_edit.TabIndex = 2;
            this.bt_edit.Text = "Editar";
            this.bt_edit.UseVisualStyleBackColor = true;
            this.bt_edit.Click += new System.EventHandler(this.bt_edit_Click);
            // 
            // FCatalogoSuperheroe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(602, 321);
            this.Controls.Add(this.bt_edit);
            this.Controls.Add(this.lbSuper);
            this.Controls.Add(this.btAgregarSuper);
            this.Name = "FCatalogoSuperheroe";
            this.Text = "FCatalogoSuperheroe";
            this.Load += new System.EventHandler(this.FCatalogoSuperheroe_Load_1);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btAgregarSuper;
        private System.Windows.Forms.ListBox lbSuper;
        private System.Windows.Forms.Button bt_edit;
    }
}